import { contextBridge, ipcRenderer } from 'electron'

contextBridge.exposeInMainWorld('electron', {
  ping: () => ipcRenderer.invoke('ping'),
  createWindow: (options) => ipcRenderer.send('create-window', options),
  saveBackup: (data) => ipcRenderer.invoke('saveBackup', data),
  loadBackup: () => ipcRenderer.invoke('loadBackup'),
  onDateLoad: (callback) => ipcRenderer.on('date-load', callback),
  closeWindow: () => ipcRenderer.send('close-window')
})
