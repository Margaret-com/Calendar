const params = new URLSearchParams(window.location.search);
let date = params.get('date') || new Date().toISOString().split('T')[0] // Get date from URL or use today's date
const ul = document.querySelector('ul')
const input = document.getElementById('noteContentArea')
const saveBtn = document.getElementById('add')
const deleteBtn = document.getElementById('delete')
const body = document.querySelector('body');
const button = document.getElementById('modeButton')
let storedItems = localStorage.getItem('items')
let itemsArray = []

if (localStorage.getItem('theme')) {
  body.className += localStorage.getItem('theme')
}

button.addEventListener('click', () => {
  if (localStorage.getItem('theme') === 'dark') {
    localStorage.removeItem('theme')
    body.className = ' '
  } else {
    localStorage.setItem('theme', 'dark');
    body.className = 'dark'
  }
})

//Function to add a task to the UI
function addTask(task) {
  const li = document.createElement('li')
  li.textContent = `Day: ${task.date} , Note: ${task.text}` || ''
  ul.appendChild(li)
}

function loadTasksForDate(selectedDate) {
  ul.innerHTML = ''
  itemsArray.filter((task) => task.date === selectedDate).forEach(addTask)
}

try {
  itemsArray = storedItems ? JSON.parse(storedItems) : []
  if (!Array.isArray(itemsArray)) {
    itemsArray = []
  }
} catch (error) {
  console.error('Failed to parse items from localStorage:', error)
  itemsArray = []
}

loadTasksForDate(date)

//Save button functionality
saveBtn.addEventListener('click', () => {
  const task = {
    date: date, // Use URL date or current date
    text: input.value
  }
  itemsArray.push(task)
  localStorage.setItem('items', JSON.stringify(itemsArray))
  addTask(task)
  input.value = ''
})

//Delete button functionality
deleteBtn.addEventListener('click', () => {
  localStorage.clear()
  ul.innerHTML = ''
  itemsArray = []
})

window.addEventListener('popstate', () => {
  date = params.get('date') || new Date().toISOString().split('T')[0]
  loadTasksForDate(date)
})
