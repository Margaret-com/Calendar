const params = new URLSearchParams(window.location.search)
let date = params.get('date') || new Date().toISOString().split('T')[0] // Get date from URL or use today's date
const daySpan = document.getElementById('to-do-list')
const saveBtn = document.getElementById('add')
const deleteBtn = document.getElementById('delete')
const body = document.querySelector('body')
const button = document.getElementById('modeButton')
const textArea = document.querySelector('textarea')
const exportButton = document.getElementById('exportNotes')
const importButton = document.getElementById('importNotes')

let storedItems = localStorage.getItem('items')
let itemsArray = []

if (localStorage.getItem('theme')) {
  body.className += localStorage.getItem('theme')
}

button.addEventListener('click', () => {
  if (localStorage.getItem('theme') === 'dark') {
    localStorage.removeItem('theme')
    body.className = ' '
  } else {
    localStorage.setItem('theme', 'dark')
    body.className = 'dark'
  }
})

//Function to add a task to the UI
function addTask(task) {
  textArea.value = task.text
  daySpan.textContent = `Day: ${task.date}`
}

function loadTasksForDate(selectedDate) {
  textArea.value = ''
  daySpan.textContent = `Day: ${selectedDate}`
  const notesForDate = itemsArray.filter((task) => task.date === selectedDate)
  if (notesForDate.length > 0) {
    textArea.value = notesForDate[0].text
  }
}

try {
  itemsArray = storedItems ? JSON.parse(storedItems) : []
  if (!Array.isArray(itemsArray)) {
    itemsArray = []
  }
} catch (error) {
  console.error('Failed to parse items from localStorage:', error)
  itemsArray = []
}

loadTasksForDate(date)

//Save button functionality
saveBtn.addEventListener('click', () => {
  if (textArea.value.trim() === '') return

  const task = {
    date: date, // Use URL date or current date
    text: textArea.value.trim()
  }

  itemsArray = itemsArray.filter((item) => item.date !== date)

  itemsArray.push(task)
  localStorage.setItem('items', JSON.stringify(itemsArray))

  const updateEvent = new CustomEvent('noteUpdated', { detail: itemsArray })
  window.dispatchEvent(updateEvent)

  addTask(task)
})

//Delete button functionality
deleteBtn.addEventListener('click', () => {
  localStorage.clear()
  itemsArray = []
  textArea.value = ''
  loadTasksForDate(new Date().toISOString().split('T')[0])

  const updateEvent = new CustomEvent('noteUpdated', { detail: itemsArray })
  window.dispatchEvent(updateEvent)

  localStorage.setItem('items', JSON.stringify(itemsArray))
})

//Export notes to a file
exportButton.addEventListener('click', () => {
  if (textArea.innerHTML !== null) {
    const blob = new Blob([storedItems], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'notes.json'
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  } else {
    alert('No notes to export.')
  }
})

//Import a file
importButton.addEventListener('change', (event) => {
  const file = event.target.files[0]

  if (file && file.type === 'application/json') {
    let reader = new FileReader()
    reader.readAsText(importButton.files[0])
    reader.onload = () => {
      try {
        const importedNotes = JSON.parse(reader.result)
        if (Array.isArray(importedNotes)) {
          localStorage.setItem('items', JSON.stringify(importedNotes))
          itemsArray = importedNotes

          const updateEvent = new CustomEvent('noteUpdated', { detail: importedNotes })
          window.dispatchEvent(updateEvent)

          alert('Notes imported successfully!')
          loadTasksForDate(date)
        } else {
          alert('Invalid format: the file must contain an array of notes.')
        }
      } catch (error) {
        alert('Error parsing the file.')
        console.error(error)
      }
    }
  } else {
    alert('Please select a valid JSON file.')
  }
})
// Handle popstate for date navigation
window.addEventListener('popstate', () => {
  date = params.get('date') || new Date().toISOString().split('T')[0]
  loadTasksForDate(date)
})
