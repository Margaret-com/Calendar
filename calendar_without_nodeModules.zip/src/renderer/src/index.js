const calendarContainer = document.getElementById('calendar')
const currentMonthLabel = document.getElementById('currentMonth')
const prevMonthbtn = document.getElementById('prevMonth')
const nextMonthbtn = document.getElementById('nextMonth')
const loadNotesButton = document.getElementById('loadNote')
const days = document.getElementById('days')
const body = document.querySelector('body')
const button = document.getElementById('modeButton')

let currentDate = new Date()
let savedNotes = localStorage.getItem('items') ? JSON.parse(localStorage.getItem('items')) : []

if (localStorage.getItem('theme')) {
  body.className += localStorage.getItem('theme')
}

button.addEventListener('click', () => {
  if (localStorage.getItem('theme') === 'dark') {
    localStorage.removeItem('theme')
    body.className = ' '
  } else {
    localStorage.setItem('theme', 'dark')
    body.className = 'dark'
  }
})

function renderCalendar(date) {
  days.innerHTML = ''
  calendarContainer.innerHTML = ''
  const year = date.getFullYear()
  const month = date.getMonth()
  const firstDayOfMonth = new Date(year, month, 1)
  const lastDayOfMonth = new Date(year, month + 1, 0)

  currentMonthLabel.textContent = `${firstDayOfMonth.toLocaleString('default', { month: 'long' })} ${year}`

  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
  const weekRow = document.createElement('div')
  weekRow.classList.add('week-row')

  daysOfWeek.forEach((day) => {
    const dayDiv = document.createElement('div')
    dayDiv.classList.add('day', 'day-of-week')
    dayDiv.textContent = day.substring(0, 3) //only first 3 letters
    weekRow.appendChild(dayDiv)
  })

  days.appendChild(weekRow)

  // Gets the number of empty boxes before the first day of the month.
  const startDay = firstDayOfMonth.getDay()
  for (let i = 0; i < startDay; i++) {
    const emptyDiv = document.createElement('div')
    emptyDiv.classList.add('day')
    calendarContainer.appendChild(emptyDiv)
  }

  // Fills the days of the month
  for (let day = 1; day <= lastDayOfMonth.getDate(); day++) {
    const dayDiv = document.createElement('div')
    dayDiv.classList.add('day')
    dayDiv.textContent = day

    const fullDate = `${year}-${(month + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`

    //Highlighting current day
    if (
      day === currentDate.getDate() &&
      month === currentDate.getMonth() &&
      year === currentDate.getFullYear()
    ) {
      dayDiv.classList.add('today') // add class for current day
    }

    // Check for notes on this day
    if (Array.isArray(savedNotes)) {
      const noteForDay = savedNotes.find((e) => e.date === fullDate)
      const eventDiv = document.createElement('div')
      if (noteForDay) {
        eventDiv.classList.add('note-indicator')
        dayDiv.appendChild(eventDiv)
      } else {
        eventDiv.classList.add('no-notes')
      }
    }

    // Makes the day clickable for adding a note.
    dayDiv.addEventListener('click', () => {
      setTimeout(() => {
        openNoteWindow(fullDate), 100
      })
      const clickedDate = new Date(fullDate)
      const dayOfWeek = clickedDate.toLocaleDateString('default', { weekday: 'long' })
      alert(`You clicked on: ${dayOfWeek}, ${fullDate}`)
    })

    calendarContainer.appendChild(dayDiv)
  }
}

//note-updated
window.addEventListener('storage', (event) => {
  if (event.key === 'items') {
    savedNotes = JSON.parse(event.newValue) || []
    renderCalendar(currentDate) //repeat render to update the calendar
  }
})

function openNoteWindow(date) {
  //open new noteWindow
  window.electron.createWindow({
    width: 400,
    height: 550,
    frame: true,
    show: true,
    selectedDate: date
  })
}

// Button to load notes from storage
loadNotesButton.addEventListener('click', () => {
  const savedNoteOfCalendar = JSON.parse(localStorage.getItem('items'))
  alert(`Saved notes: ${JSON.stringify(savedNoteOfCalendar)}`)
})

//previous-Month
prevMonthbtn.addEventListener('click', () => {
  currentDate.setMonth(currentDate.getMonth() - 1)
  renderCalendar(currentDate)
})

//next-Month
nextMonthbtn.addEventListener('click', () => {
  currentDate.setMonth(currentDate.getMonth() + 1)
  renderCalendar(currentDate)
})

renderCalendar(currentDate)