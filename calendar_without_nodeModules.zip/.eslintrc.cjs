module.exports = {
  extends: ['eslint:recommended', '@electron-toolkit', '@electron-toolkit/eslint-config-prettier']
}
